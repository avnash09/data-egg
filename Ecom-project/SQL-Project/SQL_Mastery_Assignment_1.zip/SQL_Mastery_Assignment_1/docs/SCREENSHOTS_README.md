# Screenshot Evidence

The assignment asks for screenshot evidence of executed queries and outputs.

`execution_evidence.txt` (in this folder) is a **full text capture of a clean
end-to-end run** on PostgreSQL 16 — schema creation, staging load, all 14
data-quality checks, the ETL, every Part C–G query, the stored-procedure
demonstration, and the before/after `EXPLAIN ANALYZE` plans. It is the textual
equivalent of the screenshots and proves the scripts run without errors.

To attach your own screenshots (recommended by the rubric), capture these in
your SQL client (psql / DBeaver / pgAdmin) and drop the images in this folder:

1. `01_schema_created.png` — output of `01_schema.sql` (tables created) + the ERD open.
2. `02_dq_checks.png` — the 14 DQ detection queries with their row counts.
3. `03_etl_counts.png` — analytics row counts after the ETL load.
4. `04_partC_mom.png` — C1 monthly revenue + MoM growth result grid.
5. `05_partD_shipping_delays.png` — D5 orders with shipping delays.
6. `06_partE_recursive.png` — E3 recursive category hierarchy output.
7. `07_partF_moving_avg.png` — F1 7-day moving average result.
8. `08_partG_discount.png` — the discount_log after the stored procedure runs.
9. `09_explain_before_after.png` — the two `EXPLAIN ANALYZE` plans side by side.

Naming them numerically keeps them ordered in the ZIP.
