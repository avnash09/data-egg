#!/usr/bin/env bash
# =====================================================================
# run_all.sh - build the ShopHub analytics DB end-to-end.
# Usage:
#   ./run_all.sh /path/to/olist_csv_folder [dbname]
# Requires: a running PostgreSQL 14+ and a role that can create databases.
# =====================================================================
set -euo pipefail
DATADIR="${1:?Provide the folder containing the Olist CSVs}"
DB="${2:-shophub}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo ">> Creating database $DB"
psql -v ON_ERROR_STOP=1 -c "DROP DATABASE IF EXISTS $DB;"
psql -v ON_ERROR_STOP=1 -c "CREATE DATABASE $DB;"

echo ">> 01 schema"
psql -d "$DB" -v ON_ERROR_STOP=1 -f "$HERE/sql/01_schema.sql"
echo ">> 00 load staging from $DATADIR"
psql -d "$DB" -v ON_ERROR_STOP=1 -v datadir="$DATADIR" -f "$HERE/sql/00_load_staging.sql"
echo ">> 02 data cleaning + Part B"
psql -d "$DB" -v ON_ERROR_STOP=1 -f "$HERE/sql/02_data_cleaning.sql"
echo ">> 03 analytical queries (Parts C-F)"
psql -d "$DB" -v ON_ERROR_STOP=1 -f "$HERE/sql/03_queries.sql"
echo ">> 04 stored procedures + optimization (Part G)"
psql -d "$DB" -v ON_ERROR_STOP=1 -f "$HERE/sql/04_optimization.sql"
echo ">> DONE. Database '$DB' is built and all parts executed."
