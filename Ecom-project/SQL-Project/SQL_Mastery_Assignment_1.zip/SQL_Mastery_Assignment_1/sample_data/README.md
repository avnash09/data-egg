# Sample validation data (SYNTHETIC)

These 9 CSVs are a small, **synthetic** Olist-shaped dataset used to validate
every script in this submission. They deliberately contain the data-quality
defects documented in `reports/data_quality_findings.md` (duplicate customer,
orphan item/payment, out-of-range coordinate & review score, blank category,
negative weight, whitespace/casing, payment mismatches).

They are NOT the real Olist data — download that from Kaggle
(olistbr/brazilian-ecommerce) for the full ~100K-order run. To reproduce the
validation exactly:

    psql -c "CREATE DATABASE shophub;"
    psql -d shophub -f sql/01_schema.sql
    # load these synthetic CSVs (note: filenames differ from Kaggle):
    psql -d shophub <<'SQL'
    \copy staging.stg_customers          FROM 'sample_data/customers.csv' CSV HEADER
    \copy staging.stg_geolocation        FROM 'sample_data/geolocation.csv' CSV HEADER
    \copy staging.stg_orders             FROM 'sample_data/orders.csv' CSV HEADER
    \copy staging.stg_order_items        FROM 'sample_data/order_items.csv' CSV HEADER
    \copy staging.stg_order_payments     FROM 'sample_data/order_payments.csv' CSV HEADER
    \copy staging.stg_order_reviews      FROM 'sample_data/order_reviews.csv' CSV HEADER
    \copy staging.stg_products           FROM 'sample_data/products.csv' CSV HEADER
    \copy staging.stg_sellers            FROM 'sample_data/sellers.csv' CSV HEADER
    \copy staging.stg_category_translation FROM 'sample_data/category_translation.csv' CSV HEADER
    SQL
    psql -d shophub -f sql/02_data_cleaning.sql
    psql -d shophub -f sql/03_queries.sql
    psql -d shophub -f sql/04_optimization.sql
