-- =====================================================================
-- 00_load_staging.sql  |  Load the raw Olist CSVs into staging.stg_*
-- Run AFTER 01_schema.sql. Uses psql \copy (client-side, no superuser
-- file access needed). Adjust :datadir to point at your CSV folder.
--
--   psql -d shophub -v datadir='/path/to/olist' -f sql/00_load_staging.sql
--
-- The filenames below match the official Kaggle download
-- (olistbr/brazilian-ecommerce). If you renamed them, edit accordingly.
-- =====================================================================
\if :{?datadir}
\else
  \set datadir '/path/to/olist'
\endif

\echo Loading staging from :datadir

\copy staging.stg_customers          FROM :'datadir/olist_customers_dataset.csv'         CSV HEADER
\copy staging.stg_geolocation        FROM :'datadir/olist_geolocation_dataset.csv'       CSV HEADER
\copy staging.stg_orders             FROM :'datadir/olist_orders_dataset.csv'            CSV HEADER
\copy staging.stg_order_items        FROM :'datadir/olist_order_items_dataset.csv'       CSV HEADER
\copy staging.stg_order_payments     FROM :'datadir/olist_order_payments_dataset.csv'    CSV HEADER
\copy staging.stg_order_reviews      FROM :'datadir/olist_order_reviews_dataset.csv'     CSV HEADER
\copy staging.stg_products           FROM :'datadir/olist_products_dataset.csv'          CSV HEADER
\copy staging.stg_sellers            FROM :'datadir/olist_sellers_dataset.csv'           CSV HEADER
\copy staging.stg_category_translation FROM :'datadir/product_category_name_translation.csv' CSV HEADER

\echo Staging load complete.
SELECT 'stg_customers' t, count(*) FROM staging.stg_customers
UNION ALL SELECT 'stg_orders', count(*) FROM staging.stg_orders
UNION ALL SELECT 'stg_order_items', count(*) FROM staging.stg_order_items
UNION ALL SELECT 'stg_order_payments', count(*) FROM staging.stg_order_payments
UNION ALL SELECT 'stg_order_reviews', count(*) FROM staging.stg_order_reviews
UNION ALL SELECT 'stg_products', count(*) FROM staging.stg_products
UNION ALL SELECT 'stg_sellers', count(*) FROM staging.stg_sellers
UNION ALL SELECT 'stg_geolocation', count(*) FROM staging.stg_geolocation
ORDER BY t;
