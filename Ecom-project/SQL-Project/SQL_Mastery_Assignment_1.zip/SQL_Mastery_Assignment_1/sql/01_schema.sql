-- =====================================================================
-- ShopHub Analytics Database  |  01_schema.sql
-- Part A: Database Design & Data Quality (Q1, Q3, Q5)
-- Target RDBMS : PostgreSQL 14+  (tested on 16.14)
-- Dataset      : Brazilian E-Commerce Public Dataset by Olist (~100K orders)
-- Author       : Avinash
-- ---------------------------------------------------------------------
-- Design notes
--   * Two layers:
--       (a) STAGING  (stg_*)  -> every column TEXT, mirrors the raw CSVs
--                               1:1 so dirty data loads without COPY errors.
--       (b) ANALYTICS (clean) -> 3NF, typed, keyed, constrained.
--   * Olist quirk: `customer_id` is issued PER ORDER; the real person is
--     `customer_unique_id`. This drives the de-duplication logic (02).
--   * geolocation raw file has MANY rows per zip prefix -> we collapse it
--     to ONE representative row per zip so it can serve as a clean
--     dimension that customers & sellers can reference by FK.
--   * COMMENT ON statements double as the machine-readable data dictionary
--     (see reports/data_dictionary.md, generated from these comments).
-- =====================================================================

DROP SCHEMA IF EXISTS staging CASCADE;
DROP SCHEMA IF EXISTS analytics CASCADE;
CREATE SCHEMA staging;
CREATE SCHEMA analytics;

SET search_path = analytics, staging, public;

-- =====================================================================
-- SECTION 1 : STAGING TABLES  (raw landing zone, all TEXT)
-- =====================================================================
-- NOTE the deliberate misspellings product_name_lenght /
-- product_description_lenght: these match the column names shipped in the
-- real Olist CSV. Renamed correctly in the analytics layer.

CREATE TABLE staging.stg_customers (
    customer_id                TEXT,
    customer_unique_id         TEXT,
    customer_zip_code_prefix   TEXT,
    customer_city              TEXT,
    customer_state             TEXT
);

CREATE TABLE staging.stg_geolocation (
    geolocation_zip_code_prefix TEXT,
    geolocation_lat             TEXT,
    geolocation_lng             TEXT,
    geolocation_city            TEXT,
    geolocation_state           TEXT
);

CREATE TABLE staging.stg_orders (
    order_id                      TEXT,
    customer_id                   TEXT,
    order_status                  TEXT,
    order_purchase_timestamp      TEXT,
    order_approved_at             TEXT,
    order_delivered_carrier_date  TEXT,
    order_delivered_customer_date TEXT,
    order_estimated_delivery_date TEXT
);

CREATE TABLE staging.stg_order_items (
    order_id            TEXT,
    order_item_id       TEXT,
    product_id          TEXT,
    seller_id           TEXT,
    shipping_limit_date TEXT,
    price               TEXT,
    freight_value       TEXT
);

CREATE TABLE staging.stg_order_payments (
    order_id             TEXT,
    payment_sequential   TEXT,
    payment_type         TEXT,
    payment_installments TEXT,
    payment_value        TEXT
);

CREATE TABLE staging.stg_order_reviews (
    review_id               TEXT,
    order_id                TEXT,
    review_score            TEXT,
    review_comment_title    TEXT,
    review_comment_message  TEXT,
    review_creation_date    TEXT,
    review_answer_timestamp TEXT
);

CREATE TABLE staging.stg_products (
    product_id                  TEXT,
    product_category_name       TEXT,
    product_name_lenght         TEXT,   -- sic (Olist spelling)
    product_description_lenght  TEXT,   -- sic (Olist spelling)
    product_photos_qty          TEXT,
    product_weight_g            TEXT,
    product_length_cm           TEXT,
    product_height_cm           TEXT,
    product_width_cm            TEXT
);

CREATE TABLE staging.stg_sellers (
    seller_id                TEXT,
    seller_zip_code_prefix   TEXT,
    seller_city              TEXT,
    seller_state             TEXT
);

CREATE TABLE staging.stg_category_translation (
    product_category_name          TEXT,
    product_category_name_english  TEXT
);

-- =====================================================================
-- SECTION 2 : ANALYTICS (3NF) TABLES
-- =====================================================================

-- ---- 2.1 product_categories -----------------------------------------
CREATE TABLE analytics.product_categories (
    category_id            SERIAL      PRIMARY KEY,
    category_name          TEXT        NOT NULL UNIQUE,
    category_name_english  TEXT
);

-- ---- 2.2 geolocation (one representative point per zip prefix) -------
CREATE TABLE analytics.geolocation (
    zip_code_prefix  INTEGER        PRIMARY KEY,
    latitude         NUMERIC(10,6),
    longitude        NUMERIC(10,6),
    city             TEXT,
    state            CHAR(2),
    CONSTRAINT chk_geo_lat CHECK (latitude  BETWEEN -90  AND 90),
    CONSTRAINT chk_geo_lng CHECK (longitude BETWEEN -180 AND 180)
);

-- ---- 2.3 customers ---------------------------------------------------
CREATE TABLE analytics.customers (
    customer_id         CHAR(32) PRIMARY KEY,
    customer_unique_id  CHAR(32) NOT NULL,
    zip_code_prefix     INTEGER  REFERENCES analytics.geolocation(zip_code_prefix),
    city                TEXT,
    state               CHAR(2)
);

-- ---- 2.4 sellers -----------------------------------------------------
CREATE TABLE analytics.sellers (
    seller_id        CHAR(32) PRIMARY KEY,
    zip_code_prefix  INTEGER  REFERENCES analytics.geolocation(zip_code_prefix),
    city             TEXT,
    state            CHAR(2)
);

-- ---- 2.5 products ----------------------------------------------------
CREATE TABLE analytics.products (
    product_id          CHAR(32) PRIMARY KEY,
    category_id         INTEGER  REFERENCES analytics.product_categories(category_id),
    weight_g            INTEGER  CHECK (weight_g            >= 0),
    length_cm           INTEGER  CHECK (length_cm           >= 0),
    height_cm           INTEGER  CHECK (height_cm           >= 0),
    width_cm            INTEGER  CHECK (width_cm            >= 0),
    photos_qty          INTEGER  CHECK (photos_qty          >= 0),
    name_length         INTEGER  CHECK (name_length         >= 0),
    description_length  INTEGER  CHECK (description_length  >= 0)
);

-- ---- 2.6 orders ------------------------------------------------------
CREATE TABLE analytics.orders (
    order_id                 CHAR(32) PRIMARY KEY,
    customer_id              CHAR(32) NOT NULL REFERENCES analytics.customers(customer_id),
    order_status             TEXT     NOT NULL,
    purchase_ts              TIMESTAMP,
    approved_ts              TIMESTAMP,
    delivered_carrier_ts     TIMESTAMP,
    delivered_customer_ts    TIMESTAMP,
    estimated_delivery_ts    TIMESTAMP,
    CONSTRAINT chk_order_status CHECK (order_status IN
        ('delivered','shipped','canceled','unavailable',
         'invoiced','processing','created','approved')),
    -- a delivery cannot physically precede the purchase
    CONSTRAINT chk_delivery_after_purchase
        CHECK (delivered_customer_ts IS NULL
               OR purchase_ts IS NULL
               OR delivered_customer_ts >= purchase_ts)
);

-- ---- 2.7 order_items (weak entity: composite PK) --------------------
CREATE TABLE analytics.order_items (
    order_id            CHAR(32)      NOT NULL REFERENCES analytics.orders(order_id),
    order_item_id       SMALLINT      NOT NULL,
    product_id          CHAR(32)      NOT NULL REFERENCES analytics.products(product_id),
    seller_id           CHAR(32)      NOT NULL REFERENCES analytics.sellers(seller_id),
    shipping_limit_ts   TIMESTAMP,
    price               NUMERIC(10,2) NOT NULL CHECK (price         >= 0),
    freight_value       NUMERIC(10,2) NOT NULL CHECK (freight_value >= 0),
    PRIMARY KEY (order_id, order_item_id)
);

-- ---- 2.8 order_payments (composite PK) ------------------------------
CREATE TABLE analytics.order_payments (
    order_id             CHAR(32)      NOT NULL REFERENCES analytics.orders(order_id),
    payment_sequential   SMALLINT      NOT NULL,
    payment_type         TEXT          NOT NULL,
    payment_installments SMALLINT      CHECK (payment_installments >= 0),
    payment_value        NUMERIC(10,2) NOT NULL CHECK (payment_value >= 0),
    PRIMARY KEY (order_id, payment_sequential),
    CONSTRAINT chk_payment_type CHECK (payment_type IN
        ('credit_card','boleto','voucher','debit_card','not_defined'))
);

-- ---- 2.9 order_reviews ----------------------------------------------
-- review_id is NOT unique (same review can map to >1 order and an order
-- can carry >1 review), so we use a surrogate key + a natural UNIQUE.
CREATE TABLE analytics.order_reviews (
    review_sk       BIGSERIAL PRIMARY KEY,
    review_id       CHAR(32)  NOT NULL,
    order_id        CHAR(32)  NOT NULL REFERENCES analytics.orders(order_id),
    review_score    SMALLINT  CHECK (review_score BETWEEN 1 AND 5),
    comment_title   TEXT,
    comment_message TEXT,
    creation_date   TIMESTAMP,
    answer_ts       TIMESTAMP,
    CONSTRAINT uq_review UNIQUE (review_id, order_id)
);

-- =====================================================================
-- SECTION 3 : DATA DICTIONARY  (COMMENT ON ...)
-- =====================================================================
COMMENT ON TABLE analytics.product_categories IS 'Reference/dimension of product categories with PT->EN translation.';
COMMENT ON COLUMN analytics.product_categories.category_id           IS 'Surrogate PK for the category.';
COMMENT ON COLUMN analytics.product_categories.category_name         IS 'Original Portuguese category name (natural key from Olist).';
COMMENT ON COLUMN analytics.product_categories.category_name_english IS 'English translation from product_category_name_translation.csv.';

COMMENT ON TABLE analytics.geolocation IS 'Zip-prefix dimension: one representative lat/lng/city/state per prefix.';
COMMENT ON COLUMN analytics.geolocation.zip_code_prefix IS 'Brazilian zip code prefix (first 5 digits). PK.';
COMMENT ON COLUMN analytics.geolocation.latitude        IS 'Representative (median) latitude for the prefix.';
COMMENT ON COLUMN analytics.geolocation.longitude       IS 'Representative (median) longitude for the prefix.';
COMMENT ON COLUMN analytics.geolocation.city            IS 'Most frequent city name for the prefix (normalized).';
COMMENT ON COLUMN analytics.geolocation.state           IS 'Two-letter Brazilian state code (UF).';

COMMENT ON TABLE analytics.customers IS 'Customer records. NB: customer_id is per-order; customer_unique_id identifies the actual person.';
COMMENT ON COLUMN analytics.customers.customer_id        IS 'Per-order customer key (PK). One physical person may own many.';
COMMENT ON COLUMN analytics.customers.customer_unique_id IS 'Stable identifier for the physical customer across orders.';
COMMENT ON COLUMN analytics.customers.zip_code_prefix    IS 'FK -> geolocation. Customer location prefix.';
COMMENT ON COLUMN analytics.customers.city               IS 'Customer city (as supplied).';
COMMENT ON COLUMN analytics.customers.state              IS 'Customer state (UF).';

COMMENT ON TABLE analytics.sellers IS 'Marketplace sellers and their location.';
COMMENT ON COLUMN analytics.sellers.seller_id       IS 'Seller PK.';
COMMENT ON COLUMN analytics.sellers.zip_code_prefix IS 'FK -> geolocation. Seller location prefix.';

COMMENT ON TABLE analytics.products IS 'Product catalogue with physical attributes and category FK.';
COMMENT ON COLUMN analytics.products.product_id         IS 'Product PK.';
COMMENT ON COLUMN analytics.products.category_id        IS 'FK -> product_categories.';
COMMENT ON COLUMN analytics.products.weight_g           IS 'Product weight in grams.';
COMMENT ON COLUMN analytics.products.name_length        IS 'Character length of the product name (renamed from misspelled lenght).';
COMMENT ON COLUMN analytics.products.description_length IS 'Character length of the product description.';

COMMENT ON TABLE analytics.orders IS 'Order header. One row per order_id; grain = order.';
COMMENT ON COLUMN analytics.orders.order_id              IS 'Order PK.';
COMMENT ON COLUMN analytics.orders.customer_id           IS 'FK -> customers (per-order key).';
COMMENT ON COLUMN analytics.orders.order_status          IS 'Lifecycle status (delivered, shipped, canceled, ...).';
COMMENT ON COLUMN analytics.orders.purchase_ts           IS 'Timestamp the order was placed.';
COMMENT ON COLUMN analytics.orders.approved_ts           IS 'Timestamp payment was approved.';
COMMENT ON COLUMN analytics.orders.delivered_carrier_ts  IS 'Timestamp handed to logistics carrier.';
COMMENT ON COLUMN analytics.orders.delivered_customer_ts IS 'Timestamp delivered to the customer.';
COMMENT ON COLUMN analytics.orders.estimated_delivery_ts IS 'Promised/estimated delivery timestamp.';

COMMENT ON TABLE analytics.order_items IS 'Order line items. Grain = one physical unit line (order_id, order_item_id).';
COMMENT ON COLUMN analytics.order_items.order_item_id IS 'Sequential line number within the order (1..N).';
COMMENT ON COLUMN analytics.order_items.price         IS 'Item price in BRL (revenue driver).';
COMMENT ON COLUMN analytics.order_items.freight_value IS 'Freight/shipping charge for the line in BRL.';

COMMENT ON TABLE analytics.order_payments IS 'Payment transactions. An order may split across several payment rows.';
COMMENT ON COLUMN analytics.order_payments.payment_sequential   IS 'Sequence number of the payment within the order.';
COMMENT ON COLUMN analytics.order_payments.payment_type         IS 'credit_card / boleto / voucher / debit_card / not_defined.';
COMMENT ON COLUMN analytics.order_payments.payment_installments IS 'Number of installments chosen by the customer.';
COMMENT ON COLUMN analytics.order_payments.payment_value        IS 'Amount paid on this payment row in BRL.';

COMMENT ON TABLE analytics.order_reviews IS 'Customer reviews tied to orders (1..5 stars + free text).';
COMMENT ON COLUMN analytics.order_reviews.review_sk    IS 'Surrogate PK (review_id is not unique).';
COMMENT ON COLUMN analytics.order_reviews.review_score IS 'Star rating 1..5.';

-- =====================================================================
-- End of 01_schema.sql
-- =====================================================================
