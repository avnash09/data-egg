-- =====================================================================
-- ShopHub Analytics Database  |  02_data_cleaning.sql
-- Part A Q2 & Q4  +  Part B (Q1-Q5)
-- Prereq: run 01_schema.sql and COPY the raw CSVs into staging.stg_* first.
-- =====================================================================
SET search_path = analytics, staging, public;

-- =====================================================================
-- SECTION 0 : SAFE-CAST HELPERS
--   Raw staging is all TEXT and contains junk. A direct ::int / ::numeric
--   would abort the whole statement on the first bad value, so we wrap
--   casts in functions that return NULL on failure.
-- =====================================================================
CREATE OR REPLACE FUNCTION staging.safe_int(t TEXT) RETURNS INTEGER AS $$
BEGIN  RETURN NULLIF(trim(t),'')::INTEGER;
EXCEPTION WHEN others THEN RETURN NULL;
END; $$ LANGUAGE plpgsql IMMUTABLE;

CREATE OR REPLACE FUNCTION staging.safe_num(t TEXT) RETURNS NUMERIC AS $$
BEGIN  RETURN NULLIF(trim(t),'')::NUMERIC;
EXCEPTION WHEN others THEN RETURN NULL;
END; $$ LANGUAGE plpgsql IMMUTABLE;

CREATE OR REPLACE FUNCTION staging.safe_ts(t TEXT) RETURNS TIMESTAMP AS $$
BEGIN  RETURN NULLIF(trim(t),'')::TIMESTAMP;
EXCEPTION WHEN others THEN RETURN NULL;
END; $$ LANGUAGE plpgsql IMMUTABLE;

-- =====================================================================
-- PART A Q2 : DATA QUALITY DETECTION  (10+ issues)
--   Each block below quantifies one class of problem. The narrative write
--   up lives in reports/data_quality_findings.md; these are the queries
--   that produced the numbers.
-- =====================================================================

-- DQ-01  Duplicate zip prefixes in geolocation (many rows per prefix)
SELECT 'DQ-01 dup geolocation prefixes' AS issue, count(*) AS offending_rows
FROM (SELECT geolocation_zip_code_prefix
      FROM staging.stg_geolocation
      GROUP BY 1 HAVING count(*) > 1) d;

-- DQ-02  Out-of-range latitude/longitude
SELECT 'DQ-02 geo out-of-range coords' AS issue, count(*) AS offending_rows
FROM staging.stg_geolocation
WHERE staging.safe_num(geolocation_lat) NOT BETWEEN -90 AND 90
   OR staging.safe_num(geolocation_lng) NOT BETWEEN -180 AND 180;

-- DQ-03  Leading/trailing whitespace in text fields
SELECT 'DQ-03 whitespace in city/state' AS issue, count(*) AS offending_rows
FROM staging.stg_customers
WHERE customer_city  <> trim(customer_city)
   OR customer_state <> trim(customer_state);

-- DQ-04  Inconsistent letter-casing for state codes (checked across sources)
SELECT 'DQ-04 non-uppercase state' AS issue, count(*) AS offending_rows
FROM (
    SELECT customer_state AS st FROM staging.stg_customers
    UNION ALL SELECT geolocation_state FROM staging.stg_geolocation
    UNION ALL SELECT seller_state      FROM staging.stg_sellers
) s
WHERE NULLIF(trim(st),'') IS NOT NULL
  AND trim(st) <> upper(trim(st));

-- DQ-05  Exact duplicate customer rows (same customer_id)
SELECT 'DQ-05 exact duplicate customer_id' AS issue, count(*) AS offending_rows
FROM (SELECT customer_id FROM staging.stg_customers
      GROUP BY customer_id HAVING count(*) > 1) d;

-- DQ-06  One physical person (customer_unique_id) mapped to many customer_id
SELECT 'DQ-06 unique_id -> multiple customer_id' AS issue, count(*) AS people_affected
FROM (SELECT customer_unique_id FROM staging.stg_customers
      GROUP BY customer_unique_id HAVING count(DISTINCT customer_id) > 1) d;

-- DQ-07  Products with missing/blank category
SELECT 'DQ-07 missing product category' AS issue, count(*) AS offending_rows
FROM staging.stg_products
WHERE NULLIF(trim(product_category_name),'') IS NULL;

-- DQ-08  Negative / non-numeric product weight
SELECT 'DQ-08 invalid product weight' AS issue, count(*) AS offending_rows
FROM staging.stg_products
WHERE staging.safe_num(product_weight_g) IS NULL
   OR staging.safe_num(product_weight_g) < 0;

-- DQ-09  Orphan order_items (order_id or product_id not present)
SELECT 'DQ-09 orphan order_items' AS issue, count(*) AS offending_rows
FROM staging.stg_order_items i
LEFT JOIN staging.stg_orders   o ON o.order_id  = i.order_id
LEFT JOIN staging.stg_products p ON p.product_id = i.product_id
WHERE o.order_id IS NULL OR p.product_id IS NULL;

-- DQ-10  Orphan payments (order_id not present in orders)
SELECT 'DQ-10 orphan payments' AS issue, count(*) AS offending_rows
FROM staging.stg_order_payments pay
LEFT JOIN staging.stg_orders o ON o.order_id = pay.order_id
WHERE o.order_id IS NULL;

-- DQ-11  Review scores outside the valid 1..5 range
SELECT 'DQ-11 review score out of range' AS issue, count(*) AS offending_rows
FROM staging.stg_order_reviews
WHERE staging.safe_int(review_score) NOT BETWEEN 1 AND 5;

-- DQ-12  Delivered timestamp earlier than purchase timestamp (impossible)
SELECT 'DQ-12 delivered before purchase' AS issue, count(*) AS offending_rows
FROM staging.stg_orders
WHERE staging.safe_ts(order_delivered_customer_date) IS NOT NULL
  AND staging.safe_ts(order_delivered_customer_date)
      < staging.safe_ts(order_purchase_timestamp);

-- DQ-13  Delivered orders missing the actual delivery timestamp
SELECT 'DQ-13 delivered w/o delivery ts' AS issue, count(*) AS offending_rows
FROM staging.stg_orders
WHERE order_status = 'delivered'
  AND staging.safe_ts(order_delivered_customer_date) IS NULL;

-- DQ-14  Payment total not matching order line-item total (fraud/leakage)
SELECT 'DQ-14 payment vs order total mismatch' AS issue, count(*) AS offending_rows
FROM (
    SELECT o.order_id,
           COALESCE(SUM(staging.safe_num(i.price) + staging.safe_num(i.freight_value)),0) AS order_total,
           COALESCE(p.pay_total,0)                    AS pay_total
    FROM staging.stg_orders o
    LEFT JOIN staging.stg_order_items i ON i.order_id = o.order_id
    LEFT JOIN (SELECT order_id, SUM(staging.safe_num(payment_value)) pay_total
               FROM staging.stg_order_payments GROUP BY order_id) p
           ON p.order_id = o.order_id
    GROUP BY o.order_id, p.pay_total
) x
WHERE abs(order_total - pay_total) > 1.00;

-- =====================================================================
-- PART A Q4 : DE-DUPLICATE CUSTOMERS, KEEP MOST RECENT RECORD
--   "Most recent" = the customer_id row tied to the latest order.
--   Strategy: rank rows per customer_id by their latest purchase date,
--   keep rank 1, delete the rest. Demonstrated here on staging.
-- =====================================================================
DROP TABLE IF EXISTS staging.customers_deduped;
CREATE TABLE staging.customers_deduped AS
WITH last_order AS (          -- latest purchase per customer_id
    SELECT customer_id, MAX(staging.safe_ts(order_purchase_timestamp)) AS last_purchase
    FROM staging.stg_orders GROUP BY customer_id
),
ranked AS (
    SELECT c.*,
           ROW_NUMBER() OVER (
             PARTITION BY c.customer_id
             ORDER BY lo.last_purchase DESC NULLS LAST, c.ctid
           ) AS rn
    FROM staging.stg_customers c
    LEFT JOIN last_order lo ON lo.customer_id = c.customer_id
)
SELECT customer_id, customer_unique_id, customer_zip_code_prefix,
       customer_city, customer_state
FROM ranked
WHERE rn = 1;

-- =====================================================================
-- SECTION : STAGING -> ANALYTICS  ETL LOAD (idempotent)
-- =====================================================================
TRUNCATE analytics.order_reviews, analytics.order_payments, analytics.order_items,
         analytics.orders, analytics.products, analytics.sellers,
         analytics.customers, analytics.geolocation, analytics.product_categories
RESTART IDENTITY CASCADE;

-- 1) product_categories  (translation + any category seen only in products)
INSERT INTO analytics.product_categories (category_name, category_name_english)
SELECT DISTINCT trim(t.product_category_name), trim(t.product_category_name_english)
FROM staging.stg_category_translation t
WHERE NULLIF(trim(t.product_category_name),'') IS NOT NULL;

INSERT INTO analytics.product_categories (category_name)
SELECT DISTINCT trim(p.product_category_name)
FROM staging.stg_products p
WHERE NULLIF(trim(p.product_category_name),'') IS NOT NULL
  AND trim(p.product_category_name) NOT IN
      (SELECT category_name FROM analytics.product_categories);

-- 2) geolocation dimension: 1 row per prefix (median coords, modal city/state),
--    dropping impossible coordinates and normalizing text.
INSERT INTO analytics.geolocation (zip_code_prefix, latitude, longitude, city, state)
SELECT zip,
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lat) AS latitude,
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lng) AS longitude,
       MODE() WITHIN GROUP (ORDER BY city)  AS city,
       MODE() WITHIN GROUP (ORDER BY state) AS state
FROM (
    SELECT staging.safe_int(geolocation_zip_code_prefix)      AS zip,
           staging.safe_num(geolocation_lat)                  AS lat,
           staging.safe_num(geolocation_lng)                  AS lng,
           initcap(trim(geolocation_city))                    AS city,
           upper(trim(geolocation_state))                     AS state
    FROM staging.stg_geolocation
) s
WHERE zip IS NOT NULL
  AND lat BETWEEN -90 AND 90
  AND lng BETWEEN -180 AND 180
GROUP BY zip;

-- 2b) backfill any customer/seller zip prefixes missing from geolocation so
--     the FKs hold (placeholder rows, coords left NULL, state carried over).
INSERT INTO analytics.geolocation (zip_code_prefix, state, city)
SELECT DISTINCT zip, st, ct FROM (
    SELECT staging.safe_int(customer_zip_code_prefix) zip,
           upper(trim(customer_state)) st, initcap(trim(customer_city)) ct
    FROM staging.stg_customers
    UNION
    SELECT staging.safe_int(seller_zip_code_prefix),
           upper(trim(seller_state)), initcap(trim(seller_city))
    FROM staging.stg_sellers
) z
WHERE zip IS NOT NULL
  AND zip NOT IN (SELECT zip_code_prefix FROM analytics.geolocation);

-- 3) products  (map category, safe numeric casts, clamp negatives to NULL)
INSERT INTO analytics.products
    (product_id, category_id, weight_g, length_cm, height_cm, width_cm,
     photos_qty, name_length, description_length)
SELECT p.product_id,
       pc.category_id,
       NULLIF(GREATEST(staging.safe_int(p.product_weight_g), 0), NULL),
       staging.safe_int(p.product_length_cm),
       staging.safe_int(p.product_height_cm),
       staging.safe_int(p.product_width_cm),
       staging.safe_int(p.product_photos_qty),
       staging.safe_int(p.product_name_lenght),
       staging.safe_int(p.product_description_lenght)
FROM staging.stg_products p
LEFT JOIN analytics.product_categories pc
       ON pc.category_name = trim(p.product_category_name)
WHERE p.product_id IS NOT NULL
  -- drop rows whose numeric fields are invalid (e.g. negative weight)
  AND (staging.safe_num(p.product_weight_g) IS NULL OR staging.safe_num(p.product_weight_g) >= 0);

-- 4) customers  (from the de-duplicated set; trim + normalize)
INSERT INTO analytics.customers (customer_id, customer_unique_id, zip_code_prefix, city, state)
SELECT customer_id,
       customer_unique_id,
       staging.safe_int(customer_zip_code_prefix),
       initcap(trim(customer_city)),
       upper(trim(customer_state))
FROM staging.customers_deduped;

-- 5) sellers
INSERT INTO analytics.sellers (seller_id, zip_code_prefix, city, state)
SELECT DISTINCT ON (seller_id)
       seller_id,
       staging.safe_int(seller_zip_code_prefix),
       initcap(trim(seller_city)),
       upper(trim(seller_state))
FROM staging.stg_sellers
ORDER BY seller_id;

-- 6) orders (only those whose customer survived de-dup; safe timestamp casts)
INSERT INTO analytics.orders
    (order_id, customer_id, order_status, purchase_ts, approved_ts,
     delivered_carrier_ts, delivered_customer_ts, estimated_delivery_ts)
SELECT o.order_id, o.customer_id, trim(o.order_status),
       staging.safe_ts(o.order_purchase_timestamp),
       staging.safe_ts(o.order_approved_at),
       staging.safe_ts(o.order_delivered_carrier_date),
       staging.safe_ts(o.order_delivered_customer_date),
       staging.safe_ts(o.order_estimated_delivery_date)
FROM staging.stg_orders o
JOIN analytics.customers c ON c.customer_id = o.customer_id;

-- 7) order_items  (DROP ORPHANS: order & product must exist)
INSERT INTO analytics.order_items
    (order_id, order_item_id, product_id, seller_id, shipping_limit_ts, price, freight_value)
SELECT i.order_id, staging.safe_int(i.order_item_id), i.product_id, i.seller_id,
       staging.safe_ts(i.shipping_limit_date),
       staging.safe_num(i.price), staging.safe_num(i.freight_value)
FROM staging.stg_order_items i
JOIN analytics.orders   o ON o.order_id   = i.order_id
JOIN analytics.products p ON p.product_id = i.product_id
JOIN analytics.sellers  s ON s.seller_id  = i.seller_id
WHERE staging.safe_num(i.price) >= 0;

-- 8) order_payments  (DROP ORPHANS: order must exist)
INSERT INTO analytics.order_payments
    (order_id, payment_sequential, payment_type, payment_installments, payment_value)
SELECT pay.order_id, staging.safe_int(pay.payment_sequential),
       trim(pay.payment_type), staging.safe_int(pay.payment_installments),
       staging.safe_num(pay.payment_value)
FROM staging.stg_order_payments pay
JOIN analytics.orders o ON o.order_id = pay.order_id
WHERE trim(pay.payment_type) IN
      ('credit_card','boleto','voucher','debit_card','not_defined');

-- 9) order_reviews  (drop out-of-range scores; order must exist)
INSERT INTO analytics.order_reviews
    (review_id, order_id, review_score, comment_title, comment_message, creation_date, answer_ts)
SELECT r.review_id, r.order_id, staging.safe_int(r.review_score),
       NULLIF(trim(r.review_comment_title),''),
       NULLIF(trim(r.review_comment_message),''),
       staging.safe_ts(r.review_creation_date),
       staging.safe_ts(r.review_answer_timestamp)
FROM staging.stg_order_reviews r
JOIN analytics.orders o ON o.order_id = r.order_id
WHERE staging.safe_int(r.review_score) BETWEEN 1 AND 5;

-- =====================================================================
-- PART B Q1 : LOAD WITH TRANSACTIONS  (COMMIT / ROLLBACK demonstration)
--   Shows atomic loading: a batch that violates a constraint is rolled
--   back entirely, a valid batch is committed.
-- =====================================================================

-- (a) ROLLBACK demo: valid rows inserted inside a transaction are discarded
--     entirely when we ROLLBACK -> proves atomicity of a load batch.
BEGIN;
    INSERT INTO analytics.product_categories (category_name) VALUES ('demo_tx_cat_1');
    INSERT INTO analytics.product_categories (category_name) VALUES ('demo_tx_cat_2');
    -- inside the tx the rows are visible (returns 2):
    SELECT 'inside tx (pre-rollback)' AS check, count(*) AS rows_visible
    FROM analytics.product_categories WHERE category_name LIKE 'demo_tx_cat_%';
ROLLBACK;
-- after ROLLBACK the rows are gone (returns 0):
SELECT 'after rollback' AS check, count(*) AS rows_persisted
FROM analytics.product_categories WHERE category_name LIKE 'demo_tx_cat_%';

-- (b) COMMIT demo: a clean batch persists.
BEGIN;
    INSERT INTO analytics.product_categories (category_name, category_name_english)
    VALUES ('demo_committed_cat','demo_committed_cat_en');
COMMIT;
SELECT 'after commit' AS check, count(*) AS rows_persisted
FROM analytics.product_categories WHERE category_name = 'demo_committed_cat';
-- cleanup the demo row so it doesn't pollute analytics
DELETE FROM analytics.product_categories WHERE category_name = 'demo_committed_cat';

-- (c) Atomicity under error: a constraint violation aborts the whole batch.
--     Trapped in a DO block so the script itself keeps running. The valid
--     first insert is rolled back together with the failing second one.
DO $$
BEGIN
    INSERT INTO analytics.product_categories (category_name) VALUES ('demo_err_cat');
    INSERT INTO analytics.product_categories (category_name) VALUES ('eletronicos'); -- dup -> error
EXCEPTION WHEN unique_violation THEN
    RAISE NOTICE 'Batch aborted & rolled back atomically (unique_violation) - demo_err_cat NOT persisted';
END $$;
SELECT 'after trapped error' AS check, count(*) AS rows_persisted
FROM analytics.product_categories WHERE category_name = 'demo_err_cat';   -- 0

-- =====================================================================
-- PART B Q2 : "SAME EMAIL, DIFFERENT NAME/ADDRESS"
--   Olist ships NO email/name/address columns. The faithful analog:
--   the same physical person (customer_unique_id) appearing with
--   DIFFERENT location attributes (zip/city/state) across their rows.
-- =====================================================================
SELECT customer_unique_id,
       count(*)                              AS record_count,
       count(DISTINCT zip_code_prefix)       AS distinct_zips,
       count(DISTINCT city)                  AS distinct_cities,
       string_agg(DISTINCT city, ' | ')      AS cities_seen
FROM analytics.customers
GROUP BY customer_unique_id
HAVING count(DISTINCT zip_code_prefix) > 1
    OR count(DISTINCT city)            > 1
ORDER BY record_count DESC;

-- =====================================================================
-- PART B Q3 : ORPHAN RECORDS  (detected on RAW staging, pre-clean)
-- =====================================================================
-- 3a) order_items pointing to a non-existent order
SELECT 'orphan item -> missing order' AS kind, i.order_id, i.order_item_id
FROM staging.stg_order_items i
LEFT JOIN staging.stg_orders o ON o.order_id = i.order_id
WHERE o.order_id IS NULL
UNION ALL
-- 3b) order_items pointing to a non-existent product
SELECT 'orphan item -> missing product', i.order_id, i.order_item_id
FROM staging.stg_order_items i
LEFT JOIN staging.stg_products p ON p.product_id = i.product_id
WHERE p.product_id IS NULL
UNION ALL
-- 3c) payments pointing to a non-existent order
SELECT 'orphan payment -> missing order', pay.order_id, pay.payment_sequential::text
FROM staging.stg_order_payments pay
LEFT JOIN staging.stg_orders o ON o.order_id = pay.order_id
WHERE o.order_id IS NULL;

-- =====================================================================
-- PART B Q4 : REGISTERED CUSTOMERS WHO NEVER ORDERED
--   Standard anti-join pattern. NOTE: in Olist each customer_id is minted
--   at order time, so at the customer_id grain this is usually empty. The
--   business-meaningful version is at the PERSON grain: a customer_unique_id
--   with no DELIVERED order. Both are shown.
-- =====================================================================
-- 4a) customer_id grain (classic LEFT JOIN ... IS NULL)
SELECT c.customer_id
FROM analytics.customers c
LEFT JOIN analytics.orders o ON o.customer_id = c.customer_id
WHERE o.order_id IS NULL;

-- 4b) person grain: no successfully delivered order
SELECT c.customer_unique_id
FROM analytics.customers c
WHERE NOT EXISTS (
    SELECT 1 FROM analytics.orders o
    WHERE o.customer_id = c.customer_id
      AND o.order_status = 'delivered'
)
GROUP BY c.customer_unique_id;

-- =====================================================================
-- PART B Q5 : FRAUD / LEAKAGE  (payment value <> order total)
--   Flags orders where |sum(payments) - sum(price+freight)| exceeds R$1.
-- =====================================================================
WITH order_total AS (
    SELECT order_id, SUM(price + freight_value) AS total_due
    FROM analytics.order_items GROUP BY order_id
),
paid AS (
    SELECT order_id, SUM(payment_value) AS total_paid
    FROM analytics.order_payments GROUP BY order_id
)
SELECT o.order_id,
       ot.total_due,
       COALESCE(p.total_paid,0)                       AS total_paid,
       ROUND(COALESCE(p.total_paid,0) - ot.total_due, 2) AS delta,
       CASE WHEN COALESCE(p.total_paid,0) < ot.total_due THEN 'UNDERPAID'
            ELSE 'OVERPAID' END                        AS flag
FROM analytics.orders o
JOIN order_total ot ON ot.order_id = o.order_id
LEFT JOIN paid   p  ON p.order_id  = o.order_id
WHERE abs(COALESCE(p.total_paid,0) - ot.total_due) > 1.00
ORDER BY abs(COALESCE(p.total_paid,0) - ot.total_due) DESC;

-- =====================================================================
-- End of 02_data_cleaning.sql
-- =====================================================================
