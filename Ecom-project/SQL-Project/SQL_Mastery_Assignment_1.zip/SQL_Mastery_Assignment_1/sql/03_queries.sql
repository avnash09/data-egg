-- =====================================================================
-- ShopHub Analytics Database  |  03_queries.sql
-- Part C (Aggregations) | Part D (Joins) | Part E (Subqueries/CTEs) | Part F (Windows)
-- Prereq: 01_schema.sql + 02_data_cleaning.sql already run (analytics.* populated).
-- ---------------------------------------------------------------------
-- Revenue convention: unless stated otherwise "revenue" = SUM(order_items.price)
-- for orders whose status <> 'canceled'/'unavailable'. Freight is excluded from
-- revenue (it is a pass-through cost) but shown where relevant.
-- =====================================================================
SET search_path = analytics, public;

-- =====================================================================
-- PART C : COMPLEX AGGREGATIONS
-- =====================================================================

-- ---- C1: Monthly revenue + Month-over-Month growth % ----------------
WITH monthly AS (
    SELECT date_trunc('month', o.purchase_ts)::date AS month,
           SUM(i.price)                             AS revenue
    FROM analytics.orders o
    JOIN analytics.order_items i ON i.order_id = o.order_id
    WHERE o.order_status <> 'canceled'
      AND o.purchase_ts IS NOT NULL
    GROUP BY 1
)
SELECT month,
       ROUND(revenue,2)                                        AS revenue,
       ROUND(LAG(revenue) OVER (ORDER BY month),2)             AS prev_month_revenue,
       ROUND( (revenue - LAG(revenue) OVER (ORDER BY month))
              / NULLIF(LAG(revenue) OVER (ORDER BY month),0) * 100, 2) AS mom_growth_pct
FROM monthly
ORDER BY month;

-- ---- C2: Top 10 products by revenue within each category ------------
WITH product_rev AS (
    SELECT p.product_id,
           pc.category_name_english AS category,
           SUM(i.price)             AS revenue,
           COUNT(*)                 AS units
    FROM analytics.order_items i
    JOIN analytics.products p          ON p.product_id  = i.product_id
    JOIN analytics.product_categories pc ON pc.category_id = p.category_id
    GROUP BY p.product_id, pc.category_name_english
),
ranked AS (
    SELECT *, RANK() OVER (PARTITION BY category ORDER BY revenue DESC) AS rnk
    FROM product_rev
)
SELECT category, product_id, ROUND(revenue,2) AS revenue, units, rnk
FROM ranked
WHERE rnk <= 10
ORDER BY category, rnk;

-- ---- C3: Customer Lifetime Value (CLV) + segmentation ---------------
-- CLV here = lifetime spend at the PERSON grain (customer_unique_id).
WITH person_spend AS (
    SELECT c.customer_unique_id,
           SUM(i.price)                          AS clv,
           COUNT(DISTINCT o.order_id)            AS orders,
           MIN(o.purchase_ts)                    AS first_order,
           MAX(o.purchase_ts)                    AS last_order
    FROM analytics.customers c
    JOIN analytics.orders     o ON o.customer_id = c.customer_id
    JOIN analytics.order_items i ON i.order_id   = o.order_id
    WHERE o.order_status <> 'canceled'
    GROUP BY c.customer_unique_id
)
SELECT customer_unique_id,
       ROUND(clv,2)                              AS clv,
       orders,
       ROUND(clv / orders, 2)                    AS avg_order_value,
       NTILE(4) OVER (ORDER BY clv DESC)         AS value_quartile,
       CASE
         WHEN clv >= 1000 THEN 'Platinum'
         WHEN clv >=  500 THEN 'Gold'
         WHEN clv >=  200 THEN 'Silver'
         ELSE 'Bronze'
       END                                       AS clv_segment
FROM person_spend
ORDER BY clv DESC;

-- ---- C4: Sales report with CUBE (category x year subtotals+grand) ---
-- GROUPING() flags which dimension is aggregated in each subtotal row.
SELECT COALESCE(pc.category_name_english,'<ALL CATEGORIES>') AS category,
       COALESCE(EXTRACT(YEAR FROM o.purchase_ts)::text,'<ALL YEARS>') AS yr,
       ROUND(SUM(i.price),2)                                AS revenue,
       COUNT(DISTINCT o.order_id)                           AS orders,
       GROUPING(pc.category_name_english)                   AS g_cat,
       GROUPING(EXTRACT(YEAR FROM o.purchase_ts))           AS g_year
FROM analytics.orders o
JOIN analytics.order_items i ON i.order_id = o.order_id
JOIN analytics.products p    ON p.product_id = i.product_id
JOIN analytics.product_categories pc ON pc.category_id = p.category_id
WHERE o.order_status <> 'canceled'
GROUP BY CUBE (pc.category_name_english, EXTRACT(YEAR FROM o.purchase_ts))
ORDER BY g_cat, g_year, revenue DESC;
-- MySQL note: MySQL lacks CUBE. Use  GROUP BY category, yr WITH ROLLUP
-- (ROLLUP gives hierarchical, not all-combination, subtotals).

-- ---- C5: Seasonal sales pattern by category (month-of-year) ---------
SELECT pc.category_name_english                        AS category,
       EXTRACT(MONTH FROM o.purchase_ts)::int          AS month_num,
       TO_CHAR(o.purchase_ts,'Mon')                    AS month_name,
       ROUND(SUM(i.price),2)                           AS revenue,
       COUNT(DISTINCT o.order_id)                      AS orders,
       ROUND( 100.0 * SUM(i.price)
              / SUM(SUM(i.price)) OVER (PARTITION BY pc.category_name_english), 2)
                                                        AS pct_of_category_year
FROM analytics.orders o
JOIN analytics.order_items i ON i.order_id = o.order_id
JOIN analytics.products p    ON p.product_id = i.product_id
JOIN analytics.product_categories pc ON pc.category_id = p.category_id
WHERE o.order_status <> 'canceled' AND o.purchase_ts IS NOT NULL
GROUP BY pc.category_name_english, EXTRACT(MONTH FROM o.purchase_ts), TO_CHAR(o.purchase_ts,'Mon')
ORDER BY category, month_num;

-- =====================================================================
-- PART D : MASTERING JOINS
-- =====================================================================

-- ---- D1: Customer 360-degree view ----------------------------------
SELECT c.customer_unique_id,
       MIN(c.state)                                   AS state,
       COUNT(DISTINCT o.order_id)                     AS total_orders,
       COUNT(DISTINCT o.order_id) FILTER
             (WHERE o.order_status = 'delivered')     AS delivered_orders,
       ROUND(COALESCE(SUM(i.price),0),2)              AS lifetime_revenue,
       ROUND(COALESCE(SUM(i.freight_value),0),2)      AS lifetime_freight,
       COUNT(DISTINCT pay.payment_type)               AS distinct_payment_types,
       ROUND(AVG(r.review_score),2)                   AS avg_review_score,
       MIN(o.purchase_ts)                             AS first_purchase,
       MAX(o.purchase_ts)                             AS last_purchase
FROM analytics.customers c
LEFT JOIN analytics.orders         o   ON o.customer_id = c.customer_id
LEFT JOIN analytics.order_items    i   ON i.order_id    = o.order_id
LEFT JOIN analytics.order_payments pay ON pay.order_id  = o.order_id
LEFT JOIN analytics.order_reviews  r   ON r.order_id    = o.order_id
GROUP BY c.customer_unique_id
ORDER BY lifetime_revenue DESC
LIMIT 20;

-- ---- D2: Customers who bought electronics but NEVER books ----------
SELECT DISTINCT c.customer_unique_id
FROM analytics.customers c
JOIN analytics.orders o      ON o.customer_id = c.customer_id
JOIN analytics.order_items i ON i.order_id    = o.order_id
JOIN analytics.products p    ON p.product_id  = i.product_id
JOIN analytics.product_categories pc ON pc.category_id = p.category_id
WHERE pc.category_name_english = 'electronics'
  AND c.customer_unique_id NOT IN (
        SELECT c2.customer_unique_id
        FROM analytics.customers c2
        JOIN analytics.orders o2      ON o2.customer_id = c2.customer_id
        JOIN analytics.order_items i2 ON i2.order_id    = o2.order_id
        JOIN analytics.products p2    ON p2.product_id  = i2.product_id
        JOIN analytics.product_categories pc2 ON pc2.category_id = p2.category_id
        WHERE pc2.category_name_english = 'books_technical'
  )
ORDER BY c.customer_unique_id;

-- ---- D3: Each seller's best-selling product per category -----------
WITH seller_cat_prod AS (
    SELECT i.seller_id,
           pc.category_name_english AS category,
           i.product_id,
           SUM(i.price) AS revenue
    FROM analytics.order_items i
    JOIN analytics.products p           ON p.product_id  = i.product_id
    JOIN analytics.product_categories pc ON pc.category_id = p.category_id
    GROUP BY i.seller_id, pc.category_name_english, i.product_id
)
SELECT seller_id, category, product_id, ROUND(revenue,2) AS revenue
FROM (
    SELECT *, ROW_NUMBER() OVER
              (PARTITION BY seller_id, category ORDER BY revenue DESC) AS rn
    FROM seller_cat_prod
) x
WHERE rn = 1
ORDER BY seller_id, category
LIMIT 30;

-- ---- D4: Market-basket analysis via self-join ----------------------
-- Product pairs frequently bought in the same order, with support count.
SELECT pa.category_name_english AS cat_a, a.product_id AS product_a,
       pb.category_name_english AS cat_b, b.product_id AS product_b,
       COUNT(*)                 AS times_bought_together
FROM analytics.order_items a
JOIN analytics.order_items b
       ON a.order_id = b.order_id
      AND a.product_id < b.product_id            -- avoid self & mirror pairs
JOIN analytics.products pa2 ON pa2.product_id = a.product_id
JOIN analytics.product_categories pa ON pa.category_id = pa2.category_id
JOIN analytics.products pb2 ON pb2.product_id = b.product_id
JOIN analytics.product_categories pb ON pb.category_id = pb2.category_id
GROUP BY pa.category_name_english, a.product_id, pb.category_name_english, b.product_id
HAVING COUNT(*) >= 1
ORDER BY times_bought_together DESC, product_a, product_b
LIMIT 20;

-- ---- D5: Orders with shipping delays -------------------------------
SELECT o.order_id,
       o.purchase_ts,
       o.estimated_delivery_ts,
       o.delivered_customer_ts,
       (o.delivered_customer_ts::date - o.estimated_delivery_ts::date) AS days_late
FROM analytics.orders o
WHERE o.order_status = 'delivered'
  AND o.delivered_customer_ts IS NOT NULL
  AND o.delivered_customer_ts > o.estimated_delivery_ts
ORDER BY days_late DESC
LIMIT 25;

-- =====================================================================
-- PART E : SUBQUERIES & CTEs
-- =====================================================================

-- ---- E1: Customers spending above their state's average ------------
WITH person_state_spend AS (
    SELECT c.customer_unique_id,
           MIN(c.state) AS state,
           SUM(i.price) AS spend
    FROM analytics.customers c
    JOIN analytics.orders o      ON o.customer_id = c.customer_id
    JOIN analytics.order_items i ON i.order_id    = o.order_id
    WHERE o.order_status <> 'canceled'
    GROUP BY c.customer_unique_id
),
state_avg AS (
    SELECT state, AVG(spend) AS avg_spend
    FROM person_state_spend GROUP BY state
)
SELECT p.customer_unique_id, p.state,
       ROUND(p.spend,2)        AS spend,
       ROUND(s.avg_spend,2)    AS state_avg_spend
FROM person_state_spend p
JOIN state_avg s ON s.state = p.state
WHERE p.spend > s.avg_spend
ORDER BY p.state, p.spend DESC;

-- ---- E2: 2nd highest revenue product in each category --------------
WITH product_rev AS (
    SELECT pc.category_name_english AS category, i.product_id,
           SUM(i.price) AS revenue,
           DENSE_RANK() OVER (PARTITION BY pc.category_name_english
                              ORDER BY SUM(i.price) DESC) AS drk
    FROM analytics.order_items i
    JOIN analytics.products p            ON p.product_id  = i.product_id
    JOIN analytics.product_categories pc ON pc.category_id = p.category_id
    GROUP BY pc.category_name_english, i.product_id
)
SELECT category, product_id, ROUND(revenue,2) AS revenue
FROM product_rev
WHERE drk = 2
ORDER BY category;

-- ---- E3: Product category hierarchy via RECURSIVE CTE --------------
-- Olist categories are flat, so we synthesize a super-category tree to
-- demonstrate recursion. category_tree(child -> parent).
DROP TABLE IF EXISTS analytics.category_tree;
CREATE TABLE analytics.category_tree (
    node_id   INT PRIMARY KEY,
    node_name TEXT NOT NULL,
    parent_id INT REFERENCES analytics.category_tree(node_id)
);
INSERT INTO analytics.category_tree (node_id, node_name, parent_id) VALUES
    (1,'All Products',            NULL),
    (2,'Technology',              1),
    (3,'Home & Living',           1),
    (4,'Media & Leisure',         1),
    (10,'electronics',            2),
    (11,'computers_accessories',  2),
    (12,'telephony',              2),
    (20,'bed_bath_table',         3),
    (21,'furniture_decor',        3),
    (22,'health_beauty',          3),
    (30,'books_technical',        4),
    (31,'sports_leisure',         4),
    (32,'toys',                   4),
    (33,'watches_gifts',          4);

WITH RECURSIVE tree AS (
    SELECT node_id, node_name, parent_id,
           1 AS depth,
           node_name::text AS path
    FROM analytics.category_tree
    WHERE parent_id IS NULL
  UNION ALL
    SELECT c.node_id, c.node_name, c.parent_id,
           t.depth + 1,
           t.path || ' > ' || c.node_name
    FROM analytics.category_tree c
    JOIN tree t ON c.parent_id = t.node_id
)
SELECT depth, lpad('', (depth-1)*2) || node_name AS indented_node, path
FROM tree
ORDER BY path;

-- ---- E4: Customers purchasing in 3+ CONSECUTIVE months -------------
-- "Islands" technique: consecutive months form a group when
-- (month_index - row_number) is constant per customer.
WITH cust_months AS (
    SELECT DISTINCT c.customer_unique_id,
           date_trunc('month', o.purchase_ts)::date AS mth
    FROM analytics.customers c
    JOIN analytics.orders o ON o.customer_id = c.customer_id
    WHERE o.purchase_ts IS NOT NULL
),
seq AS (
    SELECT customer_unique_id, mth,
           (EXTRACT(YEAR FROM mth)*12 + EXTRACT(MONTH FROM mth))::int AS midx,
           ROW_NUMBER() OVER (PARTITION BY customer_unique_id ORDER BY mth) AS rn
    FROM cust_months
),
islands AS (
    SELECT customer_unique_id,
           (midx - rn) AS grp,
           COUNT(*)    AS consecutive_months,
           MIN(mth)    AS streak_start,
           MAX(mth)    AS streak_end
    FROM seq
    GROUP BY customer_unique_id, (midx - rn)
)
SELECT customer_unique_id, consecutive_months, streak_start, streak_end
FROM islands
WHERE consecutive_months >= 3
ORDER BY consecutive_months DESC, customer_unique_id;

-- =====================================================================
-- PART F : ADVANCED WINDOW FUNCTIONS
-- =====================================================================

-- ---- F1: 7-day moving average of daily order count -----------------
WITH bounds AS (
    SELECT MIN(purchase_ts::date) AS d0, MAX(purchase_ts::date) AS d1
    FROM analytics.orders WHERE purchase_ts IS NOT NULL
),
calendar AS (   -- fill gap days so the moving average is continuous
    SELECT generate_series(d0, d1, interval '1 day')::date AS day FROM bounds
),
daily AS (
    SELECT cal.day,
           COUNT(o.order_id) AS orders
    FROM calendar cal
    LEFT JOIN analytics.orders o
           ON o.purchase_ts::date = cal.day
    GROUP BY cal.day
)
SELECT day, orders,
       ROUND(AVG(orders) OVER (ORDER BY day
             ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 2) AS ma_7day
FROM daily
ORDER BY day
LIMIT 40;

-- ---- F2: Gap (days) between a customer's consecutive orders (LAG) --
SELECT customer_unique_id, order_id, purchase_ts,
       prev_purchase_ts,
       (purchase_ts::date - prev_purchase_ts::date) AS days_since_prev_order
FROM (
    SELECT c.customer_unique_id, o.order_id, o.purchase_ts,
           LAG(o.purchase_ts) OVER (PARTITION BY c.customer_unique_id
                                    ORDER BY o.purchase_ts) AS prev_purchase_ts
    FROM analytics.customers c
    JOIN analytics.orders o ON o.customer_id = c.customer_id
    WHERE o.purchase_ts IS NOT NULL
) t
WHERE prev_purchase_ts IS NOT NULL
ORDER BY days_since_prev_order DESC
LIMIT 25;

-- ---- F3: Rank sellers by revenue within each state -----------------
SELECT state, seller_id, ROUND(revenue,2) AS revenue,
       RANK()       OVER (PARTITION BY state ORDER BY revenue DESC) AS rank_in_state,
       DENSE_RANK() OVER (PARTITION BY state ORDER BY revenue DESC) AS dense_rank_in_state
FROM (
    SELECT s.state, i.seller_id, SUM(i.price) AS revenue
    FROM analytics.order_items i
    JOIN analytics.sellers s ON s.seller_id = i.seller_id
    GROUP BY s.state, i.seller_id
) sr
ORDER BY state, rank_in_state
LIMIT 40;

-- ---- F4: Running revenue total + % contribution --------------------
WITH monthly AS (
    SELECT date_trunc('month', o.purchase_ts)::date AS month,
           SUM(i.price) AS revenue
    FROM analytics.orders o
    JOIN analytics.order_items i ON i.order_id = o.order_id
    WHERE o.order_status <> 'canceled' AND o.purchase_ts IS NOT NULL
    GROUP BY 1
)
SELECT month,
       ROUND(revenue,2)                                              AS revenue,
       ROUND(SUM(revenue) OVER (ORDER BY month),2)                   AS running_total,
       ROUND(100.0 * revenue / SUM(revenue) OVER (), 2)              AS pct_of_grand_total,
       ROUND(100.0 * SUM(revenue) OVER (ORDER BY month)
                   / SUM(revenue) OVER (), 2)                        AS cumulative_pct
FROM monthly
ORDER BY month;

-- =====================================================================
-- End of 03_queries.sql
-- =====================================================================
