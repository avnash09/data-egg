-- =====================================================================
-- ShopHub Analytics Database  |  04_optimization.sql
-- Part G : Stored Procedures & Optimization (Q1, Q2)
-- Prereq: 01..03 already run.
-- =====================================================================
SET search_path = analytics, public;

-- =====================================================================
-- PART G Q1 : DYNAMIC DISCOUNT CALCULATION
--   (a) scalar FUNCTION  fn_discount_pct : pure rule engine
--   (b) PROCEDURE        sp_apply_discount : computes & logs per order
--   Rules (tiered, stackable, capped at 30%):
--     * base by CLV tier  : Platinum 15 / Gold 10 / Silver 5 / Bronze 2
--     * volume bonus      : +5% if the order total >= 500 BRL
--     * loyalty bonus     : +3% if the customer has >= 5 lifetime orders
--     * installment nudge : +2% if paid in a single installment (cheaper for us)
-- =====================================================================

-- (a) Pure, deterministic rule function --------------------------------
CREATE OR REPLACE FUNCTION analytics.fn_discount_pct(
        p_clv           NUMERIC,
        p_order_total   NUMERIC,
        p_lifetime_orders INT,
        p_installments  INT DEFAULT 1)
RETURNS NUMERIC AS $$
DECLARE
    v_pct NUMERIC := 0;
BEGIN
    v_pct := CASE
                WHEN p_clv >= 1000 THEN 15
                WHEN p_clv >=  500 THEN 10
                WHEN p_clv >=  200 THEN 5
                ELSE 2
             END;
    IF p_order_total  >= 500 THEN v_pct := v_pct + 5; END IF;
    IF p_lifetime_orders >= 5 THEN v_pct := v_pct + 3; END IF;
    IF COALESCE(p_installments,1) = 1 THEN v_pct := v_pct + 2; END IF;
    RETURN LEAST(v_pct, 30);            -- hard cap
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- log table for the procedure
CREATE TABLE IF NOT EXISTS analytics.discount_log (
    order_id        CHAR(32) PRIMARY KEY,
    order_total     NUMERIC(10,2),
    discount_pct    NUMERIC(5,2),
    discount_amount NUMERIC(10,2),
    final_amount    NUMERIC(10,2),
    calculated_at   TIMESTAMP DEFAULT now()
);

-- (b) Procedure: resolve inputs for one order, compute, and upsert log --
CREATE OR REPLACE PROCEDURE analytics.sp_apply_discount(p_order_id CHAR(32))
LANGUAGE plpgsql AS $$
DECLARE
    v_total   NUMERIC;
    v_clv     NUMERIC;
    v_orders  INT;
    v_inst    INT;
    v_pct     NUMERIC;
    v_amt     NUMERIC;
BEGIN
    SELECT SUM(i.price + i.freight_value)
      INTO v_total
      FROM analytics.order_items i WHERE i.order_id = p_order_id;

    IF v_total IS NULL THEN
        RAISE NOTICE 'Order % has no items; nothing to do.', p_order_id;
        RETURN;
    END IF;

    SELECT COALESCE(SUM(i2.price),0), COUNT(DISTINCT o2.order_id)
      INTO v_clv, v_orders
      FROM analytics.orders o
      JOIN analytics.customers c  ON c.customer_id = o.customer_id
      JOIN analytics.orders     o2 ON o2.customer_id IN
            (SELECT customer_id FROM analytics.customers
             WHERE customer_unique_id = c.customer_unique_id)
      JOIN analytics.order_items i2 ON i2.order_id = o2.order_id
     WHERE o.order_id = p_order_id;

    SELECT COALESCE(MAX(payment_installments),1)
      INTO v_inst
      FROM analytics.order_payments WHERE order_id = p_order_id;

    v_pct := analytics.fn_discount_pct(v_clv, v_total, v_orders, v_inst);
    v_amt := ROUND(v_total * v_pct/100.0, 2);

    INSERT INTO analytics.discount_log AS d
        (order_id, order_total, discount_pct, discount_amount, final_amount)
    VALUES (p_order_id, ROUND(v_total,2), v_pct, v_amt, ROUND(v_total - v_amt,2))
    ON CONFLICT (order_id) DO UPDATE
        SET order_total=EXCLUDED.order_total, discount_pct=EXCLUDED.discount_pct,
            discount_amount=EXCLUDED.discount_amount, final_amount=EXCLUDED.final_amount,
            calculated_at=now();

    RAISE NOTICE 'Order % : total=% pct=%%% discount=% final=%',
        p_order_id, ROUND(v_total,2), v_pct, v_amt, ROUND(v_total-v_amt,2);
END;
$$;

-- ---- Demonstration --------------------------------------------------
-- Apply to the 5 highest-value orders, then show the log.
DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN
        SELECT o.order_id
        FROM analytics.orders o
        JOIN analytics.order_items i ON i.order_id = o.order_id
        GROUP BY o.order_id
        ORDER BY SUM(i.price+i.freight_value) DESC
        LIMIT 5
    LOOP
        CALL analytics.sp_apply_discount(r.order_id);
    END LOOP;
END $$;

SELECT order_id, order_total, discount_pct, discount_amount, final_amount
FROM analytics.discount_log
ORDER BY order_total DESC;

-- Set-based use of the pure function across ALL orders (no procedure loop):
SELECT o.order_id,
       ROUND(SUM(i.price+i.freight_value),2)                        AS order_total,
       analytics.fn_discount_pct(
            (SELECT COALESCE(SUM(i2.price),0)
               FROM analytics.orders o2
               JOIN analytics.order_items i2 ON i2.order_id=o2.order_id
              WHERE o2.customer_id=o.customer_id),
            SUM(i.price+i.freight_value),
            1, 1)                                                    AS discount_pct
FROM analytics.orders o
JOIN analytics.order_items i ON i.order_id=o.order_id
GROUP BY o.order_id, o.customer_id
ORDER BY order_total DESC
LIMIT 10;

-- =====================================================================
-- PART G Q2 : QUERY OPTIMIZATION WITH EXPLAIN ANALYZE + INDEXES
-- =====================================================================

-- ---------------------------------------------------------------------
-- 2.1  PRODUCTION INDEXES a DBA would add to the analytics schema.
--      Rationale in comments; these back the joins/filters in 03_queries.
-- ---------------------------------------------------------------------
-- FK-supporting indexes (Postgres does NOT auto-index FK columns):
CREATE INDEX IF NOT EXISTS idx_orders_customer      ON analytics.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_items_order          ON analytics.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_items_product        ON analytics.order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_items_seller         ON analytics.order_items(seller_id);
CREATE INDEX IF NOT EXISTS idx_payments_order       ON analytics.order_payments(order_id);
CREATE INDEX IF NOT EXISTS idx_reviews_order        ON analytics.order_reviews(order_id);
CREATE INDEX IF NOT EXISTS idx_products_category    ON analytics.products(category_id);
CREATE INDEX IF NOT EXISTS idx_customers_unique     ON analytics.customers(customer_unique_id);
-- Time-series filter/sort support for monthly & moving-average queries:
CREATE INDEX IF NOT EXISTS idx_orders_purchase_ts   ON analytics.orders(purchase_ts);
-- Partial index: delivered-order delay analysis only scans delivered rows:
CREATE INDEX IF NOT EXISTS idx_orders_delivered_late
    ON analytics.orders(delivered_customer_ts, estimated_delivery_ts)
    WHERE order_status = 'delivered';
-- Covering index for seller-revenue rollups (index-only scan candidate):
CREATE INDEX IF NOT EXISTS idx_items_seller_price
    ON analytics.order_items(seller_id) INCLUDE (price);

ANALYZE analytics.orders;
ANALYZE analytics.order_items;

-- ---------------------------------------------------------------------
-- 2.2  MEASURABLE BEFORE/AFTER on a LARGE table.
--      Tiny tables always seq-scan (it's cheaper), so we build a ~200K
--      row table to demonstrate a real index win with EXPLAIN ANALYZE.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS analytics.items_big;
CREATE TABLE analytics.items_big AS
SELECT (random()*100000)::int          AS order_id,
       (random()*60)::int + 1          AS product_id,
       round((random()*400+15)::numeric,2) AS price,
       (date '2017-01-01' + (random()*540)::int) AS purchase_day
FROM generate_series(1, 200000);

-- BEFORE: no index -> sequential scan + filter
-- (run these two lines interactively to see the plan)
EXPLAIN (ANALYZE, BUFFERS)
SELECT product_id, SUM(price)
FROM analytics.items_big
WHERE product_id = 42
GROUP BY product_id;

-- ADD INDEX
CREATE INDEX idx_items_big_product ON analytics.items_big(product_id);
ANALYZE analytics.items_big;

-- AFTER: same query -> index scan, far fewer rows read
EXPLAIN (ANALYZE, BUFFERS)
SELECT product_id, SUM(price)
FROM analytics.items_big
WHERE product_id = 42
GROUP BY product_id;

-- Range-scan example benefiting from a composite/time index
CREATE INDEX idx_items_big_day ON analytics.items_big(purchase_day);
ANALYZE analytics.items_big;
EXPLAIN (ANALYZE, BUFFERS)
SELECT purchase_day, COUNT(*)
FROM analytics.items_big
WHERE purchase_day BETWEEN date '2017-06-01' AND date '2017-06-30'
GROUP BY purchase_day
ORDER BY purchase_day;

-- =====================================================================
-- End of 04_optimization.sql
-- =====================================================================
